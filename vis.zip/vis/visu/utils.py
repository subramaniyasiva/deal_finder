import requests
from bs4 import BeautifulSoup

def get_amazon_price(mobile_name):
    url = f"https://www.amazon.in/s?k={mobile_name}"
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, 'html.parser')
    try:
        price = soup.find('span', {'class': 'a-price-whole'}).text.strip()
        return f"Amazon Price: ₹{price}", url
    except AttributeError:
        return "Price not available on Amazon", None

def get_flipkart_price(mobile_name):
    url = f"https://www.flipkart.com/search?q={mobile_name}"
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, 'html.parser')
    try:
        price = soup.find('div', class_= '_30jeq3 _1_WHN1').text.strip()
        return f"Flipkart Price: ₹{price}", url
    except AttributeError:
        return "Price not available on Flipkart", None
    
def get_poorvika_price(mobile_name):
    url = f"https://www.poorvika.com/s?q={mobile_name}"
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.get(url,headers=headers)
    soup = BeautifulSoup(response.content, 'html.parser')
    try:
        price = soup.find('span', class_='whitespace-nowrap').text.strip()
        return f"Poorvika's Price: ₹{price}", url
    except AttributeError:
        return "Price not available on Poorvika", None

def get_buyblynk_price(mobile_name):
    url = f'https://buyblynk.com/search?q={mobile_name}'
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.get(url,headers=headers)
    soup = BeautifulSoup(response.content, 'html.parser')
    try:
        price = soup.find('div', class_='grid-link__sale_price').find('span', class_='price-right').text.strip()
        return f"Refurbished Mobile Price: ₹{price}", url
    except AttributeError:
        return "Price not available on BuyBlynk", None

def get_mobile_prices(mobile_name):
    amazon_price, amazon_url = get_amazon_price(mobile_name)
    flipkart_price, flipkart_url = get_flipkart_price(mobile_name)
    poorvika_price, poorvika_url = get_poorvika_price(mobile_name)
    buyblynk_price, buyblynk_url = get_buyblynk_price(mobile_name)
    return amazon_price, amazon_url, flipkart_price, flipkart_url, poorvika_price, poorvika_url, buyblynk_price, buyblynk_url
