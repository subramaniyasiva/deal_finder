from django.shortcuts import render
from .utils import get_mobile_prices

def index(request):
    if request.method == 'POST':
        mobile_name = request.POST.get('mobile_name')
        prices_and_urls = get_mobile_prices(mobile_name)
        
        # Unpack the tuple into separate variables
        amazon_price, amazon_url, flipkart_price, flipkart_url, poorvika_price, poorvika_url, buyblynk_price, buyblynk_url = prices_and_urls

        return render(request, 'index.html', {
            'amazon_price': amazon_price,
            'amazon_url': amazon_url,
            'flipkart_price': flipkart_price,
            'flipkart_url': flipkart_url,
            'poorvika_price': poorvika_price,
            'poorvika_url': poorvika_url,
            'buyblynk_price': buyblynk_price,
            'buyblynk_url': buyblynk_url,
        })
    else:
        return render(request, 'index.html')
