from django.apps import AppConfig


class VisuConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'visu'
