import requests
from bs4 import BeautifulSoup
url="https://www.flipkart.com/mobiles/pr?sid=tyy%2C4io&p%5B%5D=facets.availability%255B%255D%3DExclude%2BOut%2Bof%2BStock&param=178819&p%5B%5D=facets.brand%255B%255D%3DSAMSUNG&p%5B%5D=facets.type%255B%255D%3DSmartphones&ctx=eyJjYXJkQ29udGV4dCI6eyJhdHRyaWJ1dGVzIjp7InRpdGxlIjp7Im11bHRpVmFsdWVkQXR0cmlidXRlIjp7ImtleSI6InRpdGxlIiwiaW5mZXJlbmNlVHlwZSI6IlRJVExFIiwidmFsdWVzIjpbIlNhbXN1bmcgc21hcnRwaG9uZXMiXSwidmFsdWVUeXBlIjoiTVVMVElfVkFMVUVEIn19fX19&wid=17.productCard.PMU_V2_15"
page=requests.get(url)
o=BeautifulSoup(page.text,'html.parser')
g=o.find_all('p')
t=[word.text for word in g]
for x in t:
    print(x,"\n")
